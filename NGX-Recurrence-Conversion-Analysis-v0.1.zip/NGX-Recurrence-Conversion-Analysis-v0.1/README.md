# NGX Recurrence–Conversion Analysis

**Version:** 0.1 — Preliminary  
**Status:** Active research project  
**Scope:** Nigerian listed companies  
**Initial companies:** Dangote Cement Plc; MTN Nigeria Communications Plc

## Research question

Can longitudinal analysis of Nigerian listed-company annual reports identify persistent or recurring corporate risks and determine whether they subsequently convert into measurable financial consequences?

The project deliberately distinguishes:

- **Recurrence:** the same or materially similar issue appears again.
- **Persistence:** one unresolved issue remains active across reporting periods.
- **Conversion:** the issue produces a measurable financial or governance consequence.
- **Resolution:** the exposure is subsequently settled, reversed, remediated, or otherwise closed.

A central working proposition is:

> Financial conversion does not necessarily imply resolution.

This is a **preliminary empirical project**, not a claim that the framework has already been validated across the NGX.

## Initial observations

### DCP-001 — Dangote Cement Plc

**Issue:** subsidiary financing / receivables / impairment.

The evidence reviewed for 2022–2025 indicates persistent material exposure to subsidiary receivables and continued impairment assessment. A **₦707.2 billion impairment loss** on receivables from subsidiaries was recognised in 2023. Subsequent reporting shows that material subsidiary receivables and financial support remained.

**Preliminary classification:** Persistence → Conversion → Continued exposure.

See `observations/DCP-001.md`.

### MTN-TAX-001 — MTN Nigeria Communications Plc

**Issue:** long-running VAT assessment.

The dispute originated in an approximately US$2 billion VAT-related demand in 2018, was revised by FIRS to US$135.7 million, and was litigated before the Tax Appeal Tribunal. The 2023 accounts recognised a **₦30.3 billion VAT assessment cost**. The 2025 report states that the liability was paid and that **₦4.4 billion** of excess provision was reversed.

**Preliminary classification:** Persistence → Conversion → Resolution.

This is **not coded as recurrence** because the evidence currently establishes persistence of one dispute, not repeated separate occurrences.

See `observations/MTN-TAX-001.md`.

## Method

Each observation is coded as:

`Issue → Persistence/Recurrence → Magnitude → Conversion → Resolution/Continued Exposure`

The project will not infer recurrence merely because a financial consequence is large. Every classification must be traceable to the underlying annual reports.

## Data status

Version 0.1 contains two preliminary observations. It is intentionally incomplete.

The next planned company is **GTCO**, followed by additional NGX-listed companies.

## Reproducibility

Calculations should be reproducible from the processed data in `data/processed/` and the scripts in `analysis/`.

Source reports should be stored in `data/raw/` only when redistribution rights permit. Otherwise, use the source register in this repository to identify the original report.

## Disclaimer

This repository is a research project. It does not constitute an allegation of misconduct, fraud, poor governance, or wrongdoing against any company or individual. An audit matter, provision, impairment, dispute, or recurring disclosure is not by itself evidence of misconduct.

All conclusions are limited to the evidence available in the cited reporting periods.
