# Analysis

This directory will contain reproducible scripts for:

- cleaning observation data;
- calculating exposure growth;
- calculating conversion severity;
- generating descriptive statistics;
- testing exploratory relationships.

Version 0.1 does not include a statistical model because the current sample is too small.
