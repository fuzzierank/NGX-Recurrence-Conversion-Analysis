"""Exploratory metrics for NGX Recurrence–Conversion Analysis v0.1."""

import pandas as pd

OBS = "../data/processed/observations.csv"
EXP = "../data/processed/exposure_series.csv"

def load_data():
    return pd.read_csv(OBS), pd.read_csv(EXP)

def dangote_growth():
    _, exp = load_data()
    x = exp[
        (exp.observation_id == "DCP-001")
        & (exp.metric == "non_current_receivables_from_subsidiaries")
    ].sort_values("year")
    x["growth_pct"] = x["value_ngn_billion"].pct_change() * 100
    return x[["year", "value_ngn_billion", "growth_pct"]]

if __name__ == "__main__":
    print(dangote_growth().to_string(index=False))
