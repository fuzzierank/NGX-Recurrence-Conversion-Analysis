# Coding Framework

## 1. Unit of analysis

The basic unit is:

**company × issue × reporting period**

An observation can span multiple reporting periods where the underlying issue persists or recurs.

## 2. Core states

### Recurrence
The same or materially similar issue appears again after a previous reporting period.

### Persistence
One unresolved issue remains active across multiple reporting periods.

### Conversion
The issue produces a measurable consequence, such as:
- impairment
- provision
- recognised loss
- tax assessment cost
- penalty
- write-off
- restatement
- settlement
- other clearly documented financial/governance consequence

### Resolution
The underlying exposure is documented as settled, reversed, remediated, or otherwise closed.

### Continued exposure
The consequence is recognised, but the underlying exposure remains material or the same risk remains an area of significant judgement/attention.

## 3. Evidence rule

Do not classify an observation as recurrence solely because:
- the company is exposed to the same broad business risk;
- an audit Key Audit Matter appears again;
- a provision exists in several years.

The underlying issue must be sufficiently similar to support recurrence.

## 4. Conversion rule

A conversion event must have an identifiable consequence and reporting period.

Example:

`subsidiary receivable exposure → ₦707.2bn impairment in 2023`

## 5. Resolution rule

Resolution requires evidence beyond the disappearance of a line item where possible. A line item disappearing is not automatically proof that the underlying problem was solved.

## 6. Research discipline

Separate:
1. What the report explicitly states.
2. Calculations derived from stated figures.
3. Analytical interpretation.

Do not convert correlation into causation.

Do not generalise from one company.

## 7. Planned indicators

### Persistence duration

`number of reporting periods in which the same unresolved issue remains active`

### Exposure growth

`(current exposure - prior exposure) / prior exposure`

### Conversion severity

Where appropriate:

`financial consequence / relevant exposure`

These indicators are exploratory and will be refined as the dataset grows.
