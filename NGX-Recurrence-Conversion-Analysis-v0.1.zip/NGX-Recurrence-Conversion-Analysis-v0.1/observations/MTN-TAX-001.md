# MTN-TAX-001 — MTN Nigeria Communications Plc

**Company:** MTN Nigeria Communications Plc  
**Observation ID:** MTN-TAX-001  
**Period reviewed:** 2018–2025  
**Issue class:** VAT assessment / tax dispute  
**Status:** Candidate-to-validated persistence/conversion observation

## Evidence trail

### 2018

MTN Nigeria reported that the Attorney General of the Federation demanded approximately **US$2 billion** in VAT-related tax arrears concerning periods including 2007 and 2010–2017.

### 2020

The matter was transferred for resolution between the AGF, FIRS and Nigerian Customs Service.

FIRS subsequently issued a revised assessment of approximately **US$135.7 million**, comprising:
- US$47.8 million principal tax liability
- US$87.9 million interest and penalties

### 2023

The Tax Appeal Tribunal upheld the **US$47.8 million principal liability** and set aside the US$87.9 million interest and penalty charges. MTN and FIRS appealed aspects of the decision.

MTN recognised approximately **₦30.3 billion** as VAT assessment cost.

### 2025

The 2025 annual report states that the VAT assessment liability was paid in naira at the prevailing exchange rate.

It also reports a **₦4.4 billion reversal of excess VAT provision** made in the 2023 financial year.

## Coding

| Dimension | Classification |
|---|---|
| Persistence | Yes |
| Recurrence | Not established |
| Conversion | Yes |
| Conversion event | ₦30.3bn VAT assessment cost |
| Resolution | Apparently yes, based on 2025 disclosure |
| Excess provision reversal | ₦4.4bn |

## Analytical interpretation

This is best treated as:

**Persistence → Conversion → Resolution**

It should **not** be labelled a recurrence observation merely because it appears across multiple annual reports. The current evidence describes one long-running dispute rather than repeated independent occurrences.

This distinction is deliberate and forms part of the project's methodology.

## Source record

Primary evidence is drawn from the MTN Nigeria annual reports supplied for this project, including the 2020, 2021, 2022, 2023 and 2025 reports.
