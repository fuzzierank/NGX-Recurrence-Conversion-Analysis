# Preliminary Findings — v0.1

## Finding 1: Conversion and resolution are not equivalent

DCP-001 suggests that a major financial consequence can be recognised while the underlying exposure remains material.

MTN-TAX-001 provides a contrasting pathway in which a long-running dispute produces a financial consequence and is subsequently reported as paid, with an excess provision reversed.

## Preliminary pathways

### Pathway A
**Persistence → Conversion → Continued Exposure**

Current example: DCP-001.

### Pathway B
**Persistence → Conversion → Resolution**

Current example: MTN-TAX-001.

## What we cannot conclude yet

With only two observations, we cannot estimate:
- probability of conversion;
- relationship between persistence duration and loss size;
- sector differences;
- causal effects;
- predictive power of the framework.

Those require a substantially larger panel.

## Next stage

1. Complete GTCO.
2. Add Access/Access Holdings with institutional-transition coding.
3. Add additional companies and sectors.
4. Standardise monetary units and exposure definitions.
5. Build a machine-readable observation dataset.
6. Test exploratory persistence and conversion indicators.
7. Only then consider an NGX Recurrence–Conversion Index.
